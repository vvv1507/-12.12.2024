#ifndef PERFORMANCE_H
#define PERFORMANCE_H

#include "Date.h"

// Структура для хранения информации о выступлении
typedef struct _performance {
    Date date;           // Дата выступления
    char choreographer_name[40]; // Имя хореографа
    char dancer_name[40]; // Имя танцора
    char performance_name[50];  // Название выступления
} Performance;

#endif //PERFORMANCE_H
