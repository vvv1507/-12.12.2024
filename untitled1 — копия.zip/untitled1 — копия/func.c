#include <stdio.h>       // Подключение стандартной библиотеки ввода-вывода
#include "Dancer.h"
#include "Performance.h"
#include "Choreographer.h"

#define AR_LEN 1000      // Определение константы для максимального количества записей
#define TRUE 1           // Определение константы для логического значения "истина"

// Функция для преобразования данных о танцоре в строку
void rec_to_s_dancer(char s[100], Dancer dancer) {
    sprintf(s, "Имя: %s, Стиль танца: %s, Дата зачисления: %02d.%02d.%04d",
            dancer.name, dancer.dance_style,
            dancer.enrollment_date.day,
            dancer.enrollment_date.month,
            dancer.enrollment_date.year);
}

// Функция для преобразования данных о хореографе в строку
void rec_to_s_choreographer(char s[100], Choreographer choreographer) {
    sprintf(s, "Имя: %s, Стиль танца: %s", choreographer.name, choreographer.dance_style);
}

// Функция для преобразования данных о выступлении в строку
void rec_to_s_performance(char s[100], Performance performance) {
    sprintf(s, "Дата: %02d.%02d.%04d, Танцор: %s, Название выступления: %s",
            performance.date.day, performance.date.month, performance.date.year,
            performance.dancer_name, performance.performance_name);
}

// Функция для отображения меню
void show_menu() {
    printf(
        "0. Выход\n"
        "1. О программе\n"
        "2. Загрузка данных из файла\n"
        "3. Вывод данных из файлов\n"
        "4. Выполнение запроса\n");
}

// Функция для загрузки данных о танцорах из файла
int load_dancers(char *fname, Dancer dancers[], int limit) {
    FILE *in = fopen(fname, "r"); // Открытие файла для чтения
    if (!in) {
        printf("Ошибка открытия файла!\n");
        return 0;
    }

    int count = 0;
    Dancer rec;

    // Чтение данных из файла
    while (count < limit && fscanf(in, "%s %s %d.%d.%d",
            rec.name,
            rec.dance_style,
            &rec.enrollment_date.day,
            &rec.enrollment_date.month,
            &rec.enrollment_date.year) == 5) {
        dancers[count] = rec;
        count++;
    }

    fclose(in); // Закрытие файла
    return count;
}

// Функция для загрузки данных о хореографах из файла
int load_choreographers(char *fname, Choreographer choreographers[], int limit) {
    FILE *in = fopen(fname, "r"); // Открытие файла для чтения
    if (!in) {
        printf("Ошибка открытия файла!\n");
        return 0;
    }

    int count = 0;
    Choreographer rec;

    // Чтение данных из файла
    while (count < limit && fscanf(in, "%s %s", rec.name, rec.dance_style) == 2) {
        choreographers[count] = rec;
        count++;
    }

    fclose(in); // Закрытие файла
    return count;
}

// Функция для загрузки данных о выступлениях из файла
int load_performances(char *fname, Performance performances[], int limit) {
    FILE *in = fopen(fname, "r"); // Открытие файла для чтения
    if (!in) {
        printf("Ошибка открытия файла!\n");
        return 0;
    }

    int count = 0;
    Performance rec;

    // Чтение данных из файла
    while (count < limit && fscanf(in, "%d.%d.%d %s %s %s",
            &rec.date.day,
            &rec.date.month,
            &rec.date.year,
            rec.choreographer_name,
            rec.dancer_name,
            rec.performance_name) == 6) {
        performances[count] = rec;
        count++;
    }

    fclose(in); // Закрытие файла
    return count;
}

// Функция для вывода данных в файл
void write_performances_to_file(char *fname, Performance performances[], int limit) {
    FILE *out = fopen(fname, "w"); // Открытие файла для записи
    if (!out) {
        printf("Ошибка открытия файла для записи!\n");
        return;
    }

    for (int i = 0; i < limit; i++) {
        fprintf(out, "Дата: %02d.%02d.%04d, Танцор: %s, Название выступления: %s\n",
                performances[i].date.day, performances[i].date.month, performances[i].date.year,
                performances[i].dancer_name, performances[i].performance_name);
    }

    fclose(out); // Закрытие файла
    printf("Данные успешно записаны в файл %s\n", fname);
}

// Функция для выполнения запроса
void execute_query(Performance performances[], int limit) {
    printf("Введите дату выступления (в формате ДД.ММ.ГГГГ): ");
    int day, month, year;
    scanf("%d.%d.%d", &day, &month, &year);

    int found = 0;
    for (int i = 0; i < limit; i++) {
        if (performances[i].date.day == day &&
            performances[i].date.month == month &&
            performances[i].date.year == year) {
            printf("Дата: %02d.%02d.%04d, Танцор: %s, Название выступления: %s\n",
                   performances[i].date.day, performances[i].date.month, performances[i].date.year,
                   performances[i].dancer_name, performances[i].performance_name);
            found = 1;
        }
    }

    if (!found) {
        printf("Выступлений на указанную дату не найдено.\n");
    }
}
