#ifndef DANCER_H
#define DANCER_H

#include "Date.h"

// Структура для хранения информации о танцоре
typedef struct _dancer {
    char name[40];       // Имя танцора
    char dance_style[20];// Стиль танца
    Date enrollment_date;// Дата зачисления
} Dancer;

#endif //DANCER_H
