#ifndef FUNC_H
#define FUNC_H

#include "Dancer.h"
#include "Performance.h"
#include "Choreographer.h"

void rec_to_s_dancer(char s[100], Dancer dancer);
void rec_to_s_choreographer(char s[100], Choreographer choreographer);
void rec_to_s_performance(char s[100], Performance performance);
void show_menu();
int load_dancers(char *fname, Dancer dancers[], int limit);
int load_choreographers(char *fname, Choreographer choreographers[], int limit);
int load_performances(char *fname, Performance performances[], int limit);
void write_performances_to_file(char *fname, Performance performances[], int limit);
void execute_query(Performance performances[], int limit);


#endif //FUNC_H
