#include <stdio.h>       // Подключение стандартной библиотеки ввода-вывода
#include <locale.h>      // Подключение библиотеки для работы с локалью
#include <string.h>      // Подключение библиотеки для работы со строками
#include "func.h"


#define AR_LEN 1000      // Определение константы для максимального количества записей
#define TRUE 1           // Определение константы для логического значения "истина"

// Основная функция программы
int main() {
    setlocale(LC_ALL, "C"); // Установка локали для корректного отображения текста

    Dancer dancers[AR_LEN]; // Массив для хранения данных о танцорах
    Choreographer choreographers[AR_LEN]; // Массив для хранения данных о хореографах
    Performance performances[AR_LEN]; // Массив для хранения данных о выступлениях

    int dancer_count = 0; // Количество танцоров
    int choreographer_count = 0; // Количество хореографов
    int performance_count = 0; // Количество выступлений

    while (TRUE) {
        int item = -1;
        show_menu(); // Отображение меню
        scanf("%d", &item); // Чтение выбранного пункта меню

        if (item == 0) {
            printf("Спасибо за использование моей разработки\n");
            break;
        } else if (item == 1) {
            printf("Студентка Васильева Виктория Владимировна группа 301ИС-22\n");
            printf("Тема курсового проекта: Автоматизация танцевального коллектива\n");
        } else if (item == 2) {
            dancer_count = load_dancers("dancers.txt", dancers, AR_LEN);
            choreographer_count = load_choreographers("choreographers.txt", choreographers, AR_LEN);
            performance_count = load_performances("performances.txt", performances, AR_LEN);
            printf("Данные успешно загружены из файлов\n");
        } else if (item == 3) {
            write_performances_to_file("output.txt", performances, performance_count);
        } else if (item == 4) {
            execute_query(performances, performance_count);
        } else {
            printf("Ошибка. Пункты от 0 до 4.\n");
        }

        getchar(); // Для захвата символа новой строки
    }

    return 0;
}