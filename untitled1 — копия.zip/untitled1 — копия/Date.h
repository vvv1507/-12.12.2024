#ifndef DATE_H
#define DATE_H

// Структура для хранения даты
typedef struct _date {
    int year;            // Год
    int month;           // Месяц
    int day;             // День
} Date;

#endif //DATE_H
