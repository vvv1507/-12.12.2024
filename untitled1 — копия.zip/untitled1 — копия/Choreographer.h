#ifndef CHOREOGRAPHER_H
#define CHOREOGRAPHER_H

// Структура для хранения информации о хореографе
typedef struct _choreographer {
    char name[40];       // Имя хореографа
    char dance_style[20];// Стиль танца
} Choreographer;

#endif //CHOREOGRAPHER_H
